package it.euris.gymsmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymsManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
